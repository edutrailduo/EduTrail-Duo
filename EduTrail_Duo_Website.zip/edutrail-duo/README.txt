EduTrail Duo website starter
============================

Files:
- index.html : responsive bilingual website (Bangla/English)

How to preview:
1. Open index.html in a browser.

Before publishing:
1. Replace contact@example.com with your real contact email.
2. Update sample article cards with your own verified articles.
3. The newsletter form is currently a visual/demo form. Connect a mailing-list service to collect subscribers.
4. Visa/admission details should be checked against official sources before publishing.

Free publishing:
- You can publish this static site using GitHub Pages (free) or Netlify (free tier).
- Upload index.html to a public GitHub repository and enable Settings > Pages, or deploy the folder through Netlify.
